# Define the rooms and their connections
rooms = {
    "Garage": {"north": "Kitchen", "east": "Library"},
    "Kitchen": {"south": "Garage", "east": "Living Room", "north": "Dining Room"},
    "Library": {"west": "Garage", "south": "Study"},
    "Living Room": {"west": "Kitchen", "north": "Bathroom", "east": "Bedroom"},
    "Bathroom": {"south": "Living Room", "east": "Cellar"},
    "Bedroom": {"west": "Living Room"},
    "Dining Room": {"south": "Kitchen", "item": "Dragon"},
    "Cellar": {"west": "Bathroom", "item": "Treasure"},
    "Study": {"north": "Library", "item": "Book"}
}

# Define the items and their locations
items = {
    "Rope": "Garage",
    "Flashlight": "Kitchen",
    "Sword": "Library",
    "Key": "Bedroom",
}

# Define the player's starting position and inventory
player_position = "Garage"
inventory = []

# Define the boolean variable for the zombie room lock
zombie_room_locked = True

# Main game loop
while True:
    # Print the current room and available actions
    print(f"You are in the {player_position}.")
    if player_position in items.values():
        item_name = [k for k, v in items.items() if v == player_position][0]
        print(f"There is a {item_name} here.")
    print("Available actions: move (north, south, east, west), pick up (item), inventory, quit")

    # Get the player's action choice
    action = input("> ").lower()

    # Move the player 
    if action in rooms[player_position]:
        if player_position == "Cellar" and zombie_room_locked:
            print("You can't enter the zombie room until all items are collected.")
        else:
            player_position = rooms[player_position][action]
            print(f"You have moved to the {player_position}.")

    # Interact with an item
    elif action == "pick up":
        if player_position in items.values():
            item_name = [k for k, v in items.items() if v == player_position][0]
            print(f"You have picked up the {item_name}.")
            inventory.append(item_name)
            del items[item_name]
            if not items:
                zombie_room_locked = False
                print("You have collected all the items! The zombie room is now unlocked.")
        else:
            print("There are no items to pick up in this room.")

    #player's inventory
    elif action == "inventory":
        if inventory:
            print("Your inventory:")
            for item in inventory:
                print(item)
        else:
            print("Your inventory is empty.")



import random

# Rooms
rooms = [
    "Garage",
    "Kitchen",
    "Living Room",
    "Bedroom",
    "Library",
    "Cellar",
    "Dining Room",  # Dragon room
]

# Items and location
items = {
    "Rope": "Garage",
    "Flashlight": "Kitchen",
    "Sword": "Library",
    "Key": "Bedroom",
    "Ring": "Library",
}

# Player's starting position + inventory
current_room_index = 0
inventory = []
room_history = []

# Variable for the monster room lock + quest status
dragon_room_locked = True
quest_item = "Ring"
quest_completed = False

# NPC
npcs = {
    "Explorer": {
        "dialogue": "Explorer offers side quest for his ring, located in the Library.",
        "reward": "Thanks for finding my ring! Here is your reward!"
    }
}

# Random encounters
encounters = [
    "You come across a mysterious painting.",
    "A cat crosses your path and meows at you.",
    "You just walked into a spider web ewww.",
    "You hear a strange noise; it might be a Dragon!",
]

# Main game loop
while True:
    # Starting room and actions
    current_room = rooms[current_room_index]
    print(f"\nYou are in the {current_room}.")

    # Check for items in the current room
    current_items = [item for item, location in items.items() if location == current_room]
    if current_items:
        print(f"There is a {', '.join(current_items)} here.")

    # NPC interaction
    if current_room == "Garage":
        print("You see an Explorer here. Type 'talk' to interact with him.")

    print("Available actions: move, back, pick up, inventory, enter dragon room, help, quit")

    # User input
    action = input("> ").strip().lower()

    # Move the player to the next room
    if action == "move":
        if current_room_index < len(rooms) - 1:
            room_history.append(current_room_index)  # Saves room
            current_room_index += 1
            print(f"You have moved to the {rooms[current_room_index]}.")

            # Random encounter
            encounter = random.choice(encounters)
            print(encounter)
        else:
            print("You explored all the rooms.")

    # Move player back to previous room
    elif action == "back":
        if room_history:
            current_room_index = room_history.pop()
            print(f"You have moved back to the {rooms[current_room_index]}.")
        else:
            print("You can't go back; this is the starting point.")

    # Pick up an item
    elif action == "pick up":
        if current_items:
            for item in current_items:
                print(f"You have picked up the {item}.")
                inventory.append(item)
                del items[item]
                if item == quest_item:
                    quest_completed = True
                    print("You found the Explorer's lost ring!")
            # Check if all items are collected
            if not items:
                dragon_room_locked = False
                print("You have collected all the items! You can enter the dragon room.")
        else:
            print("There are no items to pick up in this room.")

    # Talk to Explorer
    elif action == "talk":
        if current_room == "Garage":
            print(npcs["Explorer"]["dialogue"])
            if quest_completed:
                print(npcs["Explorer"]["reward"])

                if quest_item in inventory:
                    inventory.remove(quest_item)
                    quest_completed = False  # Reset quest
        else:
            print("There are no NPCs here.")

    # Show inventory
    elif action == "inventory":
        if inventory:
            print("Your inventory:")
            for item in inventory:
                print(item)
        else:
            print("Your inventory is empty.")

    # Enter the dragon room
    elif action == "enter dragon room":
        if not dragon_room_locked and current_room == "Dining Room":
            print("You have entered the dragon room and defeated the Dragon!")
            break  # End Game
        else:
            print("Collect all items before entering.")

    # Help command
    elif action == "help":
        print("Available actions: move, back, pick up, inventory, enter dragon room, help, quit")

    # Quit the game
    elif action == "quit":
        print("Thanks for playing!")
        break  # End the game

    else:
        print("Invalid action. Type 'help' for a list of available actions.")

# Player collects treasure
print("\nYou are in the Cellar.")
if "Treasure" not in inventory:
    print("You have collected your treasure! You win!")
else:
    print("You already have the treasure.")
